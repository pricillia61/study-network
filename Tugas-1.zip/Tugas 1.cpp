#include<stdio.h>

int fib_rec(int number){
	
	if(number <= 1){
		
		return number;
		
	}else{
		
		return fib_rec(number - 1) + fib_rec(number - 2);
		
	}
	
}

int memo[100];

int fib_rec_memo(int number){
	
	if(number <= 1){
		
		return number;
		
	}
	
	if(memo[number] != -1){
		
		return memo[number];
		
	}
		
	int final = memo[number];

	final =  fib_rec(number - 1) + fib_rec(number - 2);
	memo[number] = final;
		
	return final;
	
}

int main(){
	
	int number, curr_1 = 0, curr_2 = 1, temp, result1 = 0, result2 = 0;
	
	printf("Input : ");
	scanf("%d", &number);
	
	//iterative
	
	for(int i = 0 ; i < number ; i++){
		
		temp = curr_1 + curr_2;
		curr_1 = curr_2;
		curr_2 = temp;
	}

	printf("%d\n", curr_1);
	
	// Iterative analysis
 
	// Time complexity : O(n)
	// Karena dalam loop hanya dijalankan satu tugas saja. Karena inputannya n angka, maka time complexitynya O(n).

	// Space : O(1) 
	// karena hasil akhirnya hanya memakan 1 memori aja.
	
	
	//Recursive
	
	result1 = fib_rec(number);
		
	printf("%d", result1);
	
	// Recursive analysis
 
	// Time complexity : O(2^n)
	// time complexitynya O(2^n) ini didapat dari perhitungan matematike.

	// Space : O(1) 
	// karena hasil akhirnya hanya memakan 1 memori aja.
	
	printf("\n");
	
	for(int i = 0 ; i < 100 ; i++){
		
		memo[i] = -1;
		
	}
	
	result2 = fib_rec_memo(number);
	
	printf("%d", result2);

	
	// Recursive Memo Analysis
	// Time Complexity : (tidak tahuuuuu) 
	// Space : O(n)
	// karena spacenya menampung jawaban dari jumlah n yang dimasukkan
		
	return 0;
}



// Analysis akhir

// Program fibonacci dengan menggunakan recursive lebih cepat dibandingkan dengan menggunakan looping biasa.
// tetapi program fibonacci dengan mengimplementasikan memo lebih cepat dibandingkan dengan menggunakan recursive dan looping biasa.
// Hal ini dikarenakan fibonacci memo menyimpan hasil dari angka yang sudah pernah diinput.

// Program fibonacci dengan mengimplementasikan memo, memakai lebih banyak memori dibandingkan dengan 
// fibonacci recursive dan fibonacci looping, hak ini dikarenakan pada program ini, hasil yang sudah pernah diinput dimasukkan 
// kedalam memori sehingga dapat dipakai lagi tanpa perlu memprosesnya (mencari tahu jawabannya).
