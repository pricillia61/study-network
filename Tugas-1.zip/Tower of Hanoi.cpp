#include<stdio.h>

void hanoi(int disk, char from, char to, char temp){
	
	if(disk == 1){
		
		printf("Move disk 1 from %c to %c\n", from, to);
		
	}else{
		
		hanoi(disk - 1, from, temp, to);
		
		printf("Move disk %d from %c to %c\n", disk, from, to);
		
		hanoi(disk - 1, temp, to, from);
		
	}
	
}


int main(){
	
	int disk;
	
	printf("input : ");
	scanf("%d", &disk);
	printf("result : \n");
	
	hanoi(disk, 'A', 'C', 'B');
	
	return 0;
}


// Tower of Hanoi Analysis

// 1. Base case dari tower of hanoi adalah if(==1)
// 2. Tree ada di luar CPP
// 3. diatas codenya
// 4. bingung aku tu wkwkwkwk
// 5. Analysis program TOH(Tower of Hanoi) 
//    TOH dengan recursive memiliki time complexity O(2^n - 1), ini didapat dari perhitungan matematika, 
//    namun karena constanta tidak ditulis maka, time complexitynya O(2^n)
//    Untuk space pada TOH recursive adalah O(n), hal ini dikarenakan mengikuti jumlah disk yang di masukkan/diinput.
//    TOH dengan memo seharusnya memiliki time complexity yang lebih cepat dari pada TOH dengn recursive.
//    TOH dengan memo juga memiliki memory yang lebih banyak dibandingkan TOH dengan recursive, karena dia menyimpan hasil dari inputan yang pernah dimasukkan. 
